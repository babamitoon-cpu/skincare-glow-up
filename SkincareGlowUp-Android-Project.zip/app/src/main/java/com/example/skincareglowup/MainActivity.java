package com.example.skincareglowup;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new GameView(this));
    }

    static class GameView extends View {
        Paint p = new Paint(1);
        Random rnd = new Random();
        int day = 1, score = 0, step = 0, lives = 3;
        String[] names = {"Cleanser", "Serum", "Moisturizer", "Sunscreen"};
        String[] emoji = {"🫧", "💧", "🧴", "☀"};
        float buttonTop, buttonBottom;
        boolean finished = false;

        int bg = Color.rgb(255,245,247), pink = Color.rgb(232,93,138);
        int dark = Color.rgb(65,43,45), cream = Color.rgb(255,250,245);

        GameView(Context c) { super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true); }

        void txt(Canvas c, String s, float x, float y, float size, int color, Paint.Align align) {
            p.setTextSize(size); p.setColor(color); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
            c.drawText(s,x,y,p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(bg);
            float w=getWidth(), h=getHeight();

            txt(c,"SKINCARE",w/2,70,22,dark,Paint.Align.CENTER);
            txt(c,"GLOW-UP",w/2,112,40,pink,Paint.Align.CENTER);

            if(finished){
                txt(c,"✨ FINAL GLOW-UP! ✨",w/2,220,30,dark,Paint.Align.CENTER);
                txt(c,"30 days complete",w/2,275,22,dark,Paint.Align.CENTER);
                txt(c,"Score: "+score,w/2,320,26,pink,Paint.Align.CENTER);
                round(c,w/2-150,390,w/2+150,465,pink);
                txt(c,"PLAY AGAIN",w/2,438,20,Color.WHITE,Paint.Align.CENTER);
                txt(c,"Great job building a routine!",w/2,520,18,dark,Paint.Align.CENTER);
                return;
            }

            txt(c,"DAY "+day+" / 30",w/2,165,24,dark,Paint.Align.CENTER);
            p.setColor(Color.rgb(242,220,226)); c.drawRoundRect(55,185,w-55,205,12,12,p);
            p.setColor(pink); c.drawRoundRect(55,185,55+(w-110)*(day/30f),205,12,12,p);

            txt(c,"Choose the next step",w/2,265,24,dark,Paint.Align.CENTER);
            txt(c,"Routine order: Cleanser → Serum → Moisturizer → Sunscreen",w/2,300,14,dark,Paint.Align.CENTER);

            float gap=18, bw=(w-70-gap)/2, bh=115;
            float left=26, top=345;
            for(int i=0;i<4;i++){
                float x=left+(i%2)*(bw+gap), y=top+(i/2)*(bh+gap);
                round(c,x,y,x+bw,y+bh,cream);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(235,196,207));
                c.drawRoundRect(x,y,x+bw,y+bh,22,22,p); p.setStyle(Paint.Style.FILL);
                txt(c,emoji[i],x+bw/2,y+48,28,dark,Paint.Align.CENTER);
                txt(c,names[i],x+bw/2,y+88,17,dark,Paint.Align.CENTER);
            }

            txt(c,"⭐ "+score+" Glow Points     ❤️ "+lives,w/2,690,19,dark,Paint.Align.CENTER);
            txt(c,"Pick the correct next product!",w/2,730,15,pink,Paint.Align.CENTER);
        }

        void round(Canvas c,float l,float t,float r,float b,int color){
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(l,t,r,b,24,24,p);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY(), w=getWidth();
            if(finished){
                if(y>380 && y<490){ day=1; score=0; step=0; lives=3; finished=false; invalidate(); }
                return true;
            }
            float gap=18,bw=(w-70-gap)/2,bh=115,left=26,top=345;
            for(int i=0;i<4;i++){
                float bx=left+(i%2)*(bw+gap), by=top+(i/2)*(bh+gap);
                if(x>=bx&&x<=bx+bw&&y>=by&&y<=by+bh){
                    if(i==step){
                        score+=10; step++;
                        if(step==4){ day++; step=0; if(day>30) finished=true; }
                    } else {
                        lives--; score=Math.max(0,score-5);
                        if(lives<=0){ day=1; step=0; lives=3; score=Math.max(0,score-20); }
                    }
                    invalidate(); return true;
                }
            }
            return true;
        }
    }
}
