# Skincare Glow-Up

A simple portrait Android casual game prototype.

## Gameplay
- 30-day skincare challenge
- Choose the correct order: Cleanser → Serum → Moisturizer → Sunscreen
- Correct choice: +10 Glow Points
- Wrong choice: lose a life and points
- Complete Day 30 for the Final Glow-Up

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The project uses a simple custom Android View and has no third-party game engine dependency.
